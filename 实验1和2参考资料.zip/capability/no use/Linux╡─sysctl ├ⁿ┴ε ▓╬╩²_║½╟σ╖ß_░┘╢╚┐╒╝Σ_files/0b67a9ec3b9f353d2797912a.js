﻿BeautifyWidget.onSingleWidgetLoad(2, {count:6, max:8,list:[
        0,
	'http://hiphotos.baidu.com/mubanceshi/pic/item/228fc5080b759d72e8248855.jpg',
	'http://hiphotos.baidu.com/mubanceshi/pic/item/228fc5080b759d72e8248855.jpg',
	'http://hiphotos.baidu.com/mubanceshi/pic/item/927d61ccff850f5200e92824.jpg',
	'http://hiphotos.baidu.com/mubanceshi/pic/item/c754c8d14d947091562c8455.jpg',
	'http://hiphotos.baidu.com/mubanceshi/pic/item/c754c8d14d947091562c8455.jpg',
	'http://hiphotos.baidu.com/mubanceshi/pic/item/927d61ccff850f5200e92824.jpg'
 ]});//// 